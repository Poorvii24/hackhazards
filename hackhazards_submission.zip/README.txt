
🚀 Project Title
AI Wellness Companion

📌 Problem Statement
Problem Statement 2 – Smart Shopping – Data and AI for Personalized E-Commerce

🎯 Objective
This project solves the problem of personalized wellness and fitness insights by analyzing meals, tracking daily wellness activities, and providing motivational coaching.

🧠 Team & Approach
Team Name: AI Wellness Innovators

Team Members:
User (GitHub / LinkedIn / Role: Lead Developer)

Your Approach:
We chose this problem to improve people’s daily wellness by providing personalized nutrition and fitness insights. We focused on using AI to classify food images, recommend nutritious meals, and track wellness activities. Challenges included integrating multiple APIs and Groq's advanced features.

🛠️ Tech Stack
Core Technologies Used:
Frontend: Streamlit
Backend: Python
Database: Local JSON file
APIs: Spoonacular, Groq
Hosting: Streamlit Cloud

Sponsor Technologies Used:
Groq: Used Groq's LLaMA3 model for personalized wellness coaching.

✨ Key Features
✅ Meal Image Classification
✅ Wellness Tracking (Steps, Water Intake)
✅ Personalized Coaching
✅ Gamification and Streaks

📽️ Demo & Deliverables
Demo Video Link: [Paste YouTube or Loom link here]
Pitch Deck / PPT Link: [Paste Google Slides / PDF link here]

✅ Tasks & Bonus Checklist
All members of the team completed the mandatory task - ✅
All members of the team completed Bonus Task 1 - ✅
All members of the team completed Bonus Task 2 - ✅

🧪 How to Run the Project
Requirements:
- Python
- Streamlit
- APIs (Spoonacular, Groq)
- .env file with necessary keys

Local Setup:
# Clone the repo
git clone https://github.com/your-team/ai-wellness-companion

# Install dependencies
cd ai-wellness-companion
pip install -r requirements.txt

# Start Streamlit app
streamlit run success7.py

🧬 Future Scope
📈 More integrations
🛡️ Security enhancements
🌐 Localization / broader accessibility

📎 Resources / Credits
Spoonacular API
Groq API
Streamlit

🏁 Final Words
The hackathon was an exciting journey, filled with challenges and learnings. We pushed the boundaries of AI to build something meaningful, and the feedback from the community was great. Shout-out to all the amazing participants and organizers!
